﻿#include "MainWin.h"

#include <QVBoxLayout>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onReadData()
{
    if (!socket->hasPendingDatagrams())
        return;

    quint64 size = socket->pendingDatagramSize();
    char *datagram = new char[size + 1];
    socket->readDatagram(datagram, size);
    datagram[size] = 0;
    QString text(datagram);
    plnTxtLogs->appendPlainText(text);
    delete[] datagram;
}

void MainWin::init()
{
    plnTxtLogs = new QPlainTextEdit;

    QVBoxLayout *vLay = new QVBoxLayout;
    vLay->addWidget(plnTxtLogs, 1, 0);
    this->setLayout(vLay);

    socket = new QUdpSocket(this);
    socket->bind(4000);

    connect(socket, &QUdpSocket::readyRead, this, &MainWin::onReadData);
}
