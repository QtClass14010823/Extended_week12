﻿#include "MainWin.h"

#include <QGridLayout>
#include <QHostAddress>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onBtnSendClicked()
{
    QByteArray datagram = lnEditText->text().toLatin1();
    socket->writeDatagram(datagram, QHostAddress("127.0.0.1"), 4000);
}

void MainWin::init()
{
    lblText = new QLabel("Text:");
    lnEditText = new QLineEdit;
    btnSend = new QPushButton("Send");

    QGridLayout *grdLay = new QGridLayout;
    grdLay->addWidget(lblText, 0, 0);
    grdLay->addWidget(lnEditText, 0, 1);
    grdLay->addWidget(btnSend, 0, 2);
    this->setLayout(grdLay);

    socket = new QUdpSocket(this);

    connect(btnSend, &QPushButton::clicked, this, &MainWin::onBtnSendClicked);
}
