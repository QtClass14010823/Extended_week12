﻿#ifndef MAINWIN_H
#define MAINWIN_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QUdpSocket>

class MainWin : public QWidget
{
    Q_OBJECT
public:
    explicit MainWin(QWidget *parent = nullptr);

signals:

private slots:
    void onBtnSendClicked();

private:
    QUdpSocket *socket;
    QLabel *lblText;
    QLineEdit *lnEditText;
    QPushButton *btnSend;

    void init();
};

#endif // MAINWIN_H
