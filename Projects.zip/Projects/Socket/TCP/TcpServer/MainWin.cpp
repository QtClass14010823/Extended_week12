﻿#include "MainWin.h"

#include <QGridLayout>

MainWin::MainWin(QWidget *parent) : QWidget(parent)
{
    init();
}

void MainWin::onNewConnection()
{
    socket = server->nextPendingConnection();
    connect(socket, &QTcpSocket::readyRead, this, &MainWin::onReadData);
    lblClient->setText("Connection established.");
}

void MainWin::onReadData()
{
    QByteArray data = socket->readAll();
    QString text(data);
    plnTxtLogs->appendPlainText(text);
}

void MainWin::init()
{
    lblClient = new QLabel("Listening...");
    plnTxtLogs = new QPlainTextEdit;

    QGridLayout *grdLay = new QGridLayout;
    grdLay->addWidget(lblClient, 0, 0);
    grdLay->addWidget(plnTxtLogs, 1, 0);
    this->setLayout(grdLay);

    server = new QTcpServer(this);
    server->listen(QHostAddress::Any, 2000);

    connect(server, &QTcpServer::newConnection, this, &MainWin::onNewConnection);
}
