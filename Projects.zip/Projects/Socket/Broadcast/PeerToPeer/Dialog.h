﻿#ifndef DIALOG_H
#define DIALOG_H

#include <QWidget>
#include <QPlainTextEdit>

#include "PeerManager.h"

class Dialog : public QWidget
{
public:
    explicit Dialog(QWidget *parent = nullptr);

signals:

private slots:
    void newConnection(QString username);

private:
    QPlainTextEdit *plnEditText;
    PeerManager *peerMgr;
};

#endif // DIALOG_H
