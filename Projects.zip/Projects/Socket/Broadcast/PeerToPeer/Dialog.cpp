﻿#include "Dialog.h"

#include <QVBoxLayout>
#include <QRandomGenerator>

Dialog::Dialog(QWidget *parent) : QWidget(parent)
{
    plnEditText = new QPlainTextEdit;
    QVBoxLayout *vLay = new QVBoxLayout;
    vLay->addWidget(plnEditText);
    setLayout(vLay);

    peerMgr = new PeerManager("Name " + QString::number(QRandomGenerator::global()->bounded(1, 9)));
    peerMgr->startBroadcasting();
    connect(peerMgr, &PeerManager::newConnection,
            this, &Dialog::newConnection);
}

void Dialog::newConnection(QString username)
{
    plnEditText->appendPlainText(username);
}
