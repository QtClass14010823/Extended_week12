﻿#include "BlockingClient.h"

#include <QtWidgets>
#include <QtNetwork>

BlockingClient::BlockingClient(QWidget *parent)
    : QWidget(parent)
{
    hostLabel = new QLabel(tr("&Server name:"));
    portLabel = new QLabel(tr("S&erver port:"));

    // find out which IP to connect to
    QString ipAddress;
    const QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    // use the first non-localhost IPv4 address
    for (const QHostAddress &entry : ipAddressesList) {
        if (entry != QHostAddress::LocalHost && entry.toIPv4Address()) {
            ipAddress = entry.toString();
            break;
        }
    }
    // if we did not find one, use IPv4 localhost
    if (ipAddress.isEmpty())
        ipAddress = QHostAddress(QHostAddress::LocalHost).toString();

    hostLineEdit = new QLineEdit(ipAddress);
    portLineEdit = new QLineEdit;
    portLineEdit->setValidator(new QIntValidator(1, 65535, this));


    hostLabel->setBuddy(hostLineEdit);
    portLabel->setBuddy(portLineEdit);

    statusLabel = new QLabel(tr("This examples requires that you run the "
                                "Server as well."));
    statusLabel->setWordWrap(true);

    getTextButton = new QPushButton(tr("Get Text"));
    getTextButton->setDefault(true);
    getTextButton->setEnabled(false);

    quitButton = new QPushButton(tr("Quit"));

    buttonBox = new QDialogButtonBox;
    buttonBox->addButton(getTextButton, QDialogButtonBox::ActionRole);
    buttonBox->addButton(quitButton, QDialogButtonBox::RejectRole);

    connect(getTextButton, &QPushButton::clicked,
            this, &BlockingClient::requestNewText);
    connect(quitButton, &QPushButton::clicked,
            this, &BlockingClient::close);

    connect(hostLineEdit, &QLineEdit::textChanged,
            this, &BlockingClient::enableGetTextButton);
    connect(portLineEdit, &QLineEdit::textChanged,
            this, &BlockingClient::enableGetTextButton);
    connect(&thread, &SocketThread::newText,
            this, &BlockingClient::showText);
    connect(&thread, &SocketThread::error,
            this, &BlockingClient::displayError);

    QGridLayout *mainLayout = new QGridLayout;
    mainLayout->addWidget(hostLabel, 0, 0);
    mainLayout->addWidget(hostLineEdit, 0, 1);
    mainLayout->addWidget(portLabel, 1, 0);
    mainLayout->addWidget(portLineEdit, 1, 1);
    mainLayout->addWidget(statusLabel, 2, 0, 1, 2);
    mainLayout->addWidget(buttonBox, 3, 0, 1, 2);
    setLayout(mainLayout);

    setWindowTitle(tr("Blocking Client"));
    portLineEdit->setFocus();
}

void BlockingClient::requestNewText()
{
    getTextButton->setEnabled(false);
    thread.requestNewText(hostLineEdit->text(),
                             portLineEdit->text().toInt());
}

void BlockingClient::showText(const QString &nextText)
{
    if (nextText == currentText) {
        requestNewText();
        return;
    }

    currentText = nextText;
    statusLabel->setText(currentText);
    getTextButton->setEnabled(true);
}

void BlockingClient::displayError(int socketError, const QString &message)
{
    switch (socketError) {
    case QAbstractSocket::HostNotFoundError:
        QMessageBox::information(this, tr("Blocking Client"),
                                 tr("The host was not found. Please check the "
                                    "host and port settings."));
        break;
    case QAbstractSocket::ConnectionRefusedError:
        QMessageBox::information(this, tr("Blocking Client"),
                                 tr("The connection was refused by the peer. "
                                    "Make sure the server is running, "
                                    "and check that the host name and port "
                                    "settings are correct."));
        break;
    default:
        QMessageBox::information(this, tr("Blocking Client"),
                                 tr("The following error occurred: %1.")
                                 .arg(message));
    }

    getTextButton->setEnabled(true);
}

void BlockingClient::enableGetTextButton()
{
    bool enable(!hostLineEdit->text().isEmpty() && !portLineEdit->text().isEmpty());
    getTextButton->setEnabled(enable);
}
