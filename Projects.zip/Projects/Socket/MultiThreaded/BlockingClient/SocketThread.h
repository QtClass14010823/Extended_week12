﻿#ifndef SOCKETTHREAD_H
#define SOCKETTHREAD_H

#include <QThread>
#include <QMutex>
#include <QWaitCondition>

class SocketThread : public QThread
{
    Q_OBJECT

public:
    SocketThread(QObject *parent = nullptr);
    ~SocketThread();

    void requestNewText(const QString &hostName, quint16 port);
    void run() override;

signals:
    void newText(const QString &text);
    void error(int socketError, const QString &message);

private:
    QString hostName;
    quint16 port;
    QMutex mutex;
    QWaitCondition cond;
    bool quit;
};

#endif // SOCKETTHREAD_H
