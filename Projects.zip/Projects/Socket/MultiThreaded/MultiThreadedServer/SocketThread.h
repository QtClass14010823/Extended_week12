﻿#ifndef SOCKETTHREAD_H
#define SOCKETTHREAD_H

#include <QThread>
#include <QTcpSocket>

class SocketThread : public QThread
{
    Q_OBJECT

public:
    SocketThread(qintptr socketDescriptor, const QString &text, QObject *parent);

    void run() override;

signals:
    void error(QTcpSocket::SocketError socketError);

private:
    qintptr socketDescriptor;
    QString text;
};
#endif // SOCKETTHREAD_H
