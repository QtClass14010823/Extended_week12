﻿#ifndef TCPSERVER_H
#define TCPSERVER_H

#include <QStringList>
#include <QTcpServer>

class TcpServer : public QTcpServer
{
    Q_OBJECT

public:
    TcpServer(QObject *parent = nullptr);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private:
    QStringList texts;
};

#endif // TCPSERVER_H
