﻿#include <iostream>
#include <conio.h>

using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    _getch();
    return 0;
}
