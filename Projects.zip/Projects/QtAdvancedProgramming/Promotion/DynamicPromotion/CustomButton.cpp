﻿#include "CustomButton.h"

CustomButton::CustomButton(QWidget *parent/* = NULL*/)
{
    this->setStyleSheet("background-color: rgb(170, 255, 255); color: rgb(170, 0, 0);");
}

CustomButton::CustomButton(QString text, QWidget *parent/* = NULL*/) : CustomButton(parent)
{
    setText(text);
}
