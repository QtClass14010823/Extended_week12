﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->searchWidget1, &SearchBoxWidget::onSearch, this, &MainWindow::searchWidget_onSearch);
    connect(ui->searchWidget2, &SearchBoxWidget::onSearch, this, &MainWindow::searchWidget_onSearch);
    connect(ui->searchWidget3, &SearchBoxWidget::onSearch, this, &MainWindow::searchWidget_onSearch);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::searchWidget_onSearch(const QString text)
{
    QMessageBox::information(this, "information", text);
}
