﻿#include <QApplication>
#include <QWidget>
#include <QIcon>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    //a.setWindowIcon(QIcon("://AppIcon.ico"));

    QWidget w;
    w.show();
    return a.exec();
}
