﻿#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);

signals:

private slots:
    void on_RadioBtn_Toggled(bool checked);
    void on_PushBtn_Clicked(bool checked = false);

private:
    QVBoxLayout *vlay;
    QHBoxLayout *hlay;
    QObject *lastChecked;
};

#endif // FORM_H
