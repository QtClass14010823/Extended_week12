﻿#include "Form.h"

Form::Form(QWidget *parent) : QWidget(parent)
{
    workerThread = new QThread(this);
    worker = new Worker;
    worker->moveToThread(workerThread);
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting odd numbers");
    btn2 = new QPushButton("Counting even numbers");
    btn3 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);
    layout->addWidget(btn3);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
    connect(btn3, &QPushButton::clicked, this, &Form::onBtn3Clicked);
    connect(this, &Form::startWork, worker, &Worker::doWork, Qt::QueuedConnection);
    //connect(this, &Form::startWork, worker, &Worker::doWork, Qt::DirectConnection);
    //connect(this, &Form::startWork, worker, &Worker::doWork, Qt::BlockingQueuedConnection);
    connect(workerThread, &QThread::finished, worker, &QObject::deleteLater, Qt::AutoConnection);

    workerThread->start();
}

Form::~Form()
{
    if (workerThread->isRunning())
    {
        workerThread->quit();
        workerThread->wait();
    }

    //delete worker; // this is wrong, because if thread is terminated delete causes crash.
    //delete workerThread; // Enable when "workerThread = new QThread;"
}

void Form::onBtn1Clicked()
{
    emit startWork(false);
}

void Form::onBtn2Clicked()
{
    emit startWork(true);
}

void Form::onBtn3Clicked()
{
    if (workerThread->isRunning())
    {
        workerThread->terminate();
        workerThread->wait();
    }
}

void Form::onThreadFinished()
{
    worker->deleteLater();
}
