﻿#include "Form.h"

Form::Form(QWidget *parent) : QWidget(parent), settings("Settings.ini", QSettings::IniFormat)
{
    readSettings();
}

Form::~Form()
{
    writeSettings();
}

void Form::writeSettings()
{
    settings.beginGroup("Form");
    settings.setValue("size", size());
    settings.setValue("pos", pos());
    settings.endGroup();
}

void Form::readSettings()
{
    settings.beginGroup("Form");
    resize(settings.value("size", QSize(400, 400)).toSize());
    move(settings.value("pos", QPoint(200, 200)).toPoint());
    settings.endGroup();
}
