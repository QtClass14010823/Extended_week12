#include <windows.h>
#include <iostream>

using namespace std;

/*Example of Explicit Call*/
typedef int (add_proc)(int a, int b);

int main(int argc, char *argv[])
{
    add_proc *add;
    HINSTANCE h_dll;
    int a = 1, b = 2, c;
    h_dll = LoadLibrary("mathlib.dll");/*Explicit Load*/
    if(h_dll)
    {
        cout << "LoadLibrary returns " <<  h_dll << endl;
        add = (add_proc *)GetProcAddress(h_dll, "add");
        if(add)
        {
            cout << "GetProcAddress returns add = " << add << endl;
            c = add(a, b); /*Explicit Call*/
            cout << "add " << a << " + " << b << " = " << c << endl;
        }
        else
        {
            cout << "add() not found in mathlib.dll";
        }
        FreeLibrary(h_dll);
    }
    else
    {
        cout << "Unable to load mathlib.dll";
        return(-1);
    }
    return 0;
}