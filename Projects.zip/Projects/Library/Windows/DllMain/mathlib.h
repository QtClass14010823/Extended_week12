#ifndef DLL_FUNCTION
#define DLL_FUNCTION
#endif

DLL_FUNCTION int add(int, int);
DLL_FUNCTION int subtract(int, int);
DLL_FUNCTION int multiply(int, int);
DLL_FUNCTION int divition(int, int);
