#include <stdio.h>

/* Inside file1.c */
static void fun1(void)
{
    puts("fun1 called");
}
