#include <stdio.h>
#include <stddef.h>
#include <wchar.h>
#include <locale.h>

#ifdef __unix__                             /* __unix__ is usually defined by compilers targeting Unix systems */
#elif defined(_WIN32) || defined(WIN32)     /* _Win32 is usually defined by compilers targeting 32 or   64 bit Windows systems */
#include <Windows.h>
#endif

int main(void)
{
    wchar_t wc[] = L"\x639\x644\x6cc";
#ifdef __unix__                             /* __unix__ is usually defined by compilers targeting Unix systems */
#elif defined(_WIN32) || defined(WIN32)     /* _Win32 is usually defined by compilers targeting 32 or   64 bit Windows systems */
    SetConsoleOutputCP(CP_UTF8);
#endif

    setlocale(LC_ALL, "en_US.UTF-8");
    wprintf(L"%ls\n", wc);

    return 0;
}
