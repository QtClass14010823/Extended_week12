#include <iostream>

using namespace std;

int main()
{
    // Real literal
    const float floatVal = 4.14;

    cout << "Floating-point literal: "
        << floatVal << "\n";
    return 0;
}
