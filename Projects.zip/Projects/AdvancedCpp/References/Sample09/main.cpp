﻿#include <iostream>
using namespace std;

void myswap(char*& str1, char*& str2)
{
    char* temp = str1;
    str1 = str2;
    str2 = temp;
}

int main()
{
    char s1[] = {"Ali"};
    char s2[] = {"Panahi"};
    char *str1 = s1;
    char *str2 = s2;
    myswap(str1, str2);
    cout << "str1 is " << str1 << '\n';
    cout << "str2 is " << str2 << '\n';
    return 0;
}
